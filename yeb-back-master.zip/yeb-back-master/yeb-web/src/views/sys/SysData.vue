<template>
    <div>
      SysData
    </div>
</template>

<script>
    export default {
        name: "SysData"
    }
</script>

<style scoped>

</style>
