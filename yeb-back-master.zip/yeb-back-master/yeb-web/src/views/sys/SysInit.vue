<template>
    <div>
      SysInit
    </div>
</template>

<script>
    export default {
        name: "SysInit"
    }
</script>

<style scoped>

</style>
