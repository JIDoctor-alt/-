<template>
    <div>
      SysCfg
    </div>
</template>

<script>
    export default {
        name: "SysCfg"
    }
</script>

<style scoped>

</style>
