<template>
    <div>
      StaAll
    </div>
</template>

<script>
    export default {
        name: "StaAll"
    }
</script>

<style scoped>

</style>
