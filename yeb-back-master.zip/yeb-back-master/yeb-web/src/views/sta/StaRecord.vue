<template>
    <div>
      StaRecord
    </div>
</template>

<script>
    export default {
        name: "StaRecord"
    }
</script>

<style scoped>

</style>
