<template>
    <div>
      StaPers
    </div>
</template>

<script>
    export default {
        name: "StaPers"
    }
</script>

<style scoped>

</style>
