<template>
    <div>
      StaScore
    </div>
</template>

<script>
    export default {
        name: "StaScore"
    }
</script>

<style scoped>

</style>
