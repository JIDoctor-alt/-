<template>
    <div>
      SalMonth
    </div>
</template>

<script>
    export default {
        name: "SalMonth"
    }
</script>

<style scoped>

</style>
