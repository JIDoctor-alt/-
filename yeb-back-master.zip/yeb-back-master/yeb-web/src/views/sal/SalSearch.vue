<template>
    <div>
      SalSearch
    </div>
</template>

<script>
    export default {
        name: "SalSearch"
    }
</script>

<style scoped>

</style>
