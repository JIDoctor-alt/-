<template>
    <div>
      PerSalary
    </div>
</template>

<script>
    export default {
        name: "PerSalary"
    }
</script>

<style scoped>

</style>
