<template>
    <div>
      PerTrain
    </div>
</template>

<script>
    export default {
        name: "PerTrain"
    }
</script>

<style scoped>

</style>
