<template>
    <div>
      EmpAdv
    </div>
</template>

<script>
    export default {
        name: "EmpAdv"
    }
</script>

<style scoped>

</style>
